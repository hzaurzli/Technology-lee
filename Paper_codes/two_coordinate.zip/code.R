library(tidyverse)
library(readr)

regressions %>% 
  write_csv(file = "regressions.csv")
ci %>% 
  write_csv(file = "ci.csv")

dat01$deviates_table[[1]] %>% 
  write_csv(file = "deviates_table.csv")

regressions<-read_csv("regressions.csv")
head(regressions)
ci<-read_csv("ci.csv")
head(ci)
deviates_table<-read_csv("deviates_table.csv")
head(deviates_table)
dat01$ratio

library(ggplot2)
col<-"#359023"
title<-"Ampicillin *"
ratio<-27.79891
ggplot()+
  geom_point(data=deviates_table,
             aes(x=month,y=seasonal_deviate))+
  geom_errorbar(data = deviates_table, 
                aes(x = month, 
                    ymin = seasonal_deviate - sem, 
                    ymax = seasonal_deviate + sem), 
                width = 0.5, 
                color = col)+
  geom_line(data=regressions,
            aes(x = month, y = value, 
                color = leg, linetype = leg), 
            size = 0.7) +
  geom_ribbon(data = ci, 
              aes(x = month, ymin = r_lower, 
                  ymax = r_upper), 
              fill = col, 
              alpha = 0.3) +
  geom_ribbon(data = ci, 
              aes(x = month, 
                  ymin = u_upper/ratio, 
                  ymax = u_lower/ratio), 
              fill = "grey20", alpha = 0.3) +
  scale_color_manual(values = c(col, "grey20")) +
  scale_y_continuous(sec.axis = sec_axis(~. * ratio), 
                     limits = c(-.165, .165)) +
  scale_x_continuous(breaks=c(1, 3, 5, 7, 9, 11)) +
  ggtitle(title) +
  xlab("Month") +
  theme_classic() +
  guides(color = guide_legend(nrow = 2, byrow = TRUE)) +
  theme(legend.position = "bottom",
        legend.title = element_blank(),
        legend.text = element_text(size = 9),
        plot.title = element_text(size = 11, hjust = 0.5, face = "bold"),
        axis.text = element_text(size = 10),
        axis.title.y = element_blank()
  ) -> f3splot

library(ggpubr)
f3splot %>% 
  annotate_figure(left = text_grob(expression("Seasonal deviates in resistance ("*log["2"]*"(MIC))"), size = 10, rot = 90)) %>%
  annotate_figure(right = text_grob("Seasonal deviates in use\n(mean daily claims/10,000 people)", size = 10, rot = 270))
